Automated Hardware Characterization Rig — Second-Order Programmable Filter
Repeatability Run 2 of 3

Five original CSV uploads; CSV file bytes preserved unchanged. Filenames normalized inside run2/ to remove upload suffix (1).
Files: combined 120-point sweep, three per-wiper 40-point sweeps, three-row cutoff summary.
