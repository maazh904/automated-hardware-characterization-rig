Original unmodified Run 3 CSVs. Three SPI settings, 40 sweep points each (120 combined). This run is used in second_order_repeatability_all_3_runs.zip.
