Automated Hardware Characterization Rig — Second-Order Programmable Active Filter
Repeatability Run 1 (previously called Run 2 in chat).
Files were provided by the user and preserved without modification.

CSV counts:
second_order_auto_all.csv: 120 data rows; SHA256 7b0fec244feb392cc1dc894e9e04f0ac4b4b7a380ef8d19e66ad162cba54c1d6
second_order_auto_cutoffs.csv: 3 data rows; SHA256 00153c13c85536ae16c426e7187d09fe5f1c843d60880488e342f1aaf10caa5d
second_order_auto_h20.csv: 40 data rows; SHA256 0b621f2b033b18255a6156c1d96eb6bb179e4e557b09dcc0e884eabc0e0a8bda
second_order_auto_h40.csv: 40 data rows; SHA256 4b9eb588076de2982abb408f04e134decc182ff9e65f6fa44684dbe09cae0e5a
second_order_auto_h60.csv: 40 data rows; SHA256 ff8fe7481d80ad3888734eb20b218a918d26e05073e72125d14e8eac8aff1ae7
