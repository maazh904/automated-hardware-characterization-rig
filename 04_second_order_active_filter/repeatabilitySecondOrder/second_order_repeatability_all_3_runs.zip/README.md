# Second-order programmable filter: 3-run repeatability

**Hardware**: Digilent Analog Discovery 3, MCP4131-103 digital potentiometer, MCP6022 buffered two-stage RC low-pass filter.
**Data**: 3 independent automated sweeps, 40 log-spaced frequencies per SPI setting (h20/h40/h60), from 100 Hz to 20 kHz; 360 total frequency points.
**Analysis**: Overall -3.010 dB cutoff interpolated from the output/input magnitude curve. Sample standard deviation (n = 3, ddof = 1) and coefficient of variation (100 × SD / mean) are computed across the three cutoffs for each SPI setting.
**Nominal model**: H(s) = 1 / [(1 + s R1 C1)(1 + s R2 C2)], with R1 = 2220 Ω + 10000 Ω × (1 - D/128), C1 = 10 nF, R2 = 10000 Ω, C2 = 10 nF. Actual deviations may reflect components, nonideal buffers, wiring, or instrumentation.

| SPI code | Run 1 (Hz) | Run 2 (Hz) | Run 3 (Hz) | Mean (Hz) | SD (Hz) | CV (%) | Nominal theory (Hz) | Mean error (%) |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| h20 | 1010.10 | 1008.51 | 1008.29 | 1008.97 | 0.99 | 0.098 | 1038.81 | -2.87 |
| h40 | 1141.54 | 1139.42 | 1139.52 | 1140.16 | 1.20 | 0.105 | 1183.19 | -3.64 |
| h60 | 1292.04 | 1290.21 | 1290.15 | 1290.80 | 1.07 | 0.083 | 1352.96 | -4.59 |

## Included files

- `run1/`, `run2/`, `run3/`: five original unmodified CSVs per run (combined 120-point sweep, 3 individual 40-point sweeps, cutoff summary).
- `second_order_repeatability_summary.csv`: high-precision final statistics.
- `second_order_repeatability_magnitude.png`: three-run mean gain, measured spread, nominal model.
- `second_order_repeatability_phase.png`: three-run mean phase, measured spread, nominal model.
- `second_order_cutoff_repeatability.png`: mean ± SD versus nominal prediction.

### Interpretation
The coefficient of variation is approximately 0.08–0.11%, indicating high **short-term repeatability under unchanged test conditions**. This does not establish long-term calibration accuracy, component tolerance, or reproducibility across builds. All three mean cutoffs fall below the nominal model (approximately 2.9–4.6%); their direction is consistent, so the model error and run-to-run variation are distinct.
